package com.mysites.app;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.webkit.SafeBrowsingResponse;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * يفتح الموقع الأصلي داخل التطبيق فقط.
 * - يمنع الانتقال لأي موقع خارجي أو تطبيق آخر أو تنزيل ملفات.
 * - يحذّرك من المواقع غير المشفّرة، وشهادات الأمان الخاطئة، والمواقع المصنّفة خطرة من Google.
 */
public class BrowserActivity extends Activity {

    private WebView web;
    private TextView banner;
    private String baseHost;

    private static String stripWww(String h) {
        if (h == null) return "";
        h = h.toLowerCase();
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    private boolean sameSite(String host) {
        String h = stripWww(host);
        return h.equals(baseHost) || h.endsWith("." + baseHost);
    }

    private void warn(String msg) {
        banner.setText(msg);
        banner.setVisibility(View.VISIBLE);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String url = getIntent().getStringExtra("url");
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            finish();
            return;
        }
        baseHost = stripWww(Uri.parse(url).getHost());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setFitsSystemWindows(true);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#141A24"));
        bar.setPadding(24, 8, 24, 8);

        Button close = new Button(this);
        close.setText("إغلاق");
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { finish(); }
        });

        TextView host = new TextView(this);
        host.setTextColor(Color.WHITE);
        host.setTextSize(14);
        host.setSingleLine(true);
        host.setPadding(24, 0, 0, 0);
        host.setText(baseHost);

        bar.addView(close);
        bar.addView(host, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        banner = new TextView(this);
        banner.setTextColor(Color.WHITE);
        banner.setBackgroundColor(Color.parseColor("#C4312B"));
        banner.setTextSize(14);
        banner.setPadding(32, 20, 32, 20);
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { banner.setVisibility(View.GONE); }
        });

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        if (Build.VERSION.SDK_INT >= 26) {
            s.setSafeBrowsingEnabled(true);
        }

        // منع تنزيل أي ملف
        web.setDownloadListener((u, ua, cd, mime, len) ->
                warn("تم منع تنزيل ملف من هذا الموقع"));

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri t = request.getUrl();
                String scheme = t.getScheme();
                if (!"http".equals(scheme) && !"https".equals(scheme)) {
                    warn("تم منع فتح رابط خارج التطبيق (" + scheme + ")");
                    return true;
                }
                if (!sameSite(t.getHost())) {
                    warn("تم منع الانتقال إلى موقع خارجي: " + t.getHost());
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView view, String pageUrl, android.graphics.Bitmap icon) {
                if (pageUrl != null && pageUrl.startsWith("http://")) {
                    warn("هذا الموقع غير مشفّر (http). لا تدخل كلمات سر أو بيانات حساسة.");
                } else {
                    banner.setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
                warn("شهادة الأمان لهذا الموقع غير صالحة. تم إيقاف تحميل الصفحة.");
            }

            @TargetApi(27)
            @Override
            public void onSafeBrowsingHit(WebView view, WebResourceRequest request,
                                          int threatType, SafeBrowsingResponse callback) {
                callback.backToSafety(true, true);
                new AlertDialog.Builder(BrowserActivity.this)
                        .setTitle("تحذير")
                        .setMessage("هذه الصفحة مصنّفة خطرة (تصيّد أو برمجيات ضارة) وتم إيقاف تحميلها.")
                        .setPositiveButton("حسنًا", null)
                        .show();
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(banner, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        web.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
